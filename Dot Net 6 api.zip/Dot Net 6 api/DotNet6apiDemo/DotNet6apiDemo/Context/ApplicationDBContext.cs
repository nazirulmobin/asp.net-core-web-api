﻿using DotNet6apiDemo.Models;
using Microsoft.EntityFrameworkCore;

namespace DotNet6apiDemo.Context
{
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }

        public DbSet<Post> Posts { get; set; }
    }
}
