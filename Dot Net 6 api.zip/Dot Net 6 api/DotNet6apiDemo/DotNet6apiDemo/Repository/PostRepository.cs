﻿using DotNet6apiDemo.Context;
using DotNet6apiDemo.Interfaces.Repository;
using DotNet6apiDemo.Models;
using EF.Core.Repository.Repository;
using Microsoft.EntityFrameworkCore;

namespace DotNet6apiDemo.Repository
{
    public class PostRepository : CommonRepository<Post>, IpostRepository
    {
        public PostRepository(ApplicationDBContext dbContext) : base(dbContext)
        {
        }
    }
}
