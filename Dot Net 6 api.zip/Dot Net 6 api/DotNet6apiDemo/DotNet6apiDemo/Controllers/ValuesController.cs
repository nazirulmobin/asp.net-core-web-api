﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DotNet6apiDemo.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        //[Route("[Action]")]
        [HttpGet]
        public string GetName()
        {
            return "Test";
        }
        //[Route("[Action]")]
        [HttpGet]
        public string GetFullName()
        {
            return "Md. Nazirul Mobin";
        }
    }
}
