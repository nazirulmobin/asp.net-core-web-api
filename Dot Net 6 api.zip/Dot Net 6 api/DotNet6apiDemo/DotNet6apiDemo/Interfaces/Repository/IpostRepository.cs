﻿using DotNet6apiDemo.Models;
using EF.Core.Repository.Interface.Repository;

namespace DotNet6apiDemo.Interfaces.Repository
{
    public interface IpostRepository:ICommonRepository<Post>
    {
    }
}
